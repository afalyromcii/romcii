Elohim Communication — site vitrine

DÉPLOIEMENT RAPIDE
1) GitHub Pages :
   - Créez un dépôt, uploadez tout le dossier.
   - Paramètres > Pages > Branche 'main', dossier '/'.
   - L'URL publique sera fournie par GitHub.

2) Netlify :
   - netlify.com > New site from Git.
   - Build command: (vide)   Publish directory: / (racine).
   - Drag & drop possible du dossier.

3) Vercel :
   - vercel.com > Import Project > Framework: 'Other'.
   - Pas de build, dossier racine.

PERSONNALISATION
- Dans js/app.js, section COMPANY : remplacez téléphone, email, WhatsApp.
- Remplacez les images Unsplash par vos visuels.
- Mettez votre domaine dans robots.txt et sitemap.xml.

STRUCTURE
/ index.html
/ css/styles.css
/ js/app.js
/ assets/favicon.svg
/ manifest.json
/ robots.txt
/ sitemap.xml
/ 404.html (optionnel)
